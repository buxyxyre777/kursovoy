import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class CardGameClient extends JFrame {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 12345;

    private final DefaultListModel<String> handModel;
    private final JList<String> handList;
    private final JButton playButton;
    private final JTextArea messageArea;
    private final JPanel cardPanel;
    private BufferedReader in;
    private PrintWriter out;

    private final Map<String, BufferedImage> cardImages = new HashMap<>();
    private boolean turn = false; // Переменная для отслеживания хода

    public CardGameClient() {
        super("Курсовая Сундук");

        handModel = new DefaultListModel<>();
        handList = new JList<>(handModel);
        playButton = new JButton("Play");
        messageArea = new JTextArea(10, 30);
        messageArea.setEditable(false);
        cardPanel = new JPanel();

        loadCardImages();

        setLayout(new BorderLayout());
        add(new JScrollPane(cardPanel), BorderLayout.CENTER);
        add(playButton, BorderLayout.SOUTH);
        add(new JScrollPane(messageArea), BorderLayout.EAST);

        playButton.addActionListener(this::playCard);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setVisible(true);

        connectToServer();
    }

    private void loadCardImages() {
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] values = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        for (String suit : suits) {
            for (String value : values) {
                try {
                    String cardName = value + " of " + suit;
                    BufferedImage img = ImageIO.read(new File("cards/" + cardName + ".png"));
                    cardImages.put(cardName, img);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void connectToServer() {
        try {
            Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            new Thread(new IncomingReader()).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void playCard(ActionEvent e) {
        // This method is not used anymore. Cards are played by clicking on their images.
    }

    private class IncomingReader implements Runnable {
        @Override
        public void run() {
            try {
                String message;
                while ((message = in.readLine()) != null) {
                    if (message.startsWith("CARD")) {
                        String card = message.substring(5);
                        handModel.addElement(card);
                        addCardToPanel(card);
                        turn = true;
                    } else if (message.equals("Ваш ход:")) {
                        turn = true; // Устанавливаем, что сейчас ход пользователя
                        messageArea.append("Ваш ход\n");
                    } else if (message.equals("Ход противника:")) {
                        turn = false; // Устанавливаем, что сейчас ход противника
                        messageArea.append("Ход противника\n");
                    } else {
                        messageArea.append(message + "\n");
                        if (message.equals("Игра окончена")) {
                            out.close();
                            in.close();
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void addCardToPanel(String card) {
        System.out.println("Добавление карты в руку: " + card); // Логирование для отладки
        BufferedImage img = cardImages.get(card);
        if (img != null) {
            ImageIcon icon = new ImageIcon(img);
            JLabel cardLabel = new JLabel(icon);
            cardLabel.setToolTipText(card);
            cardLabel.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    if (turn) { // Проверяем, если это ход пользователя
                        out.println("PLAY " + card);
                        handModel.removeElement(card);
                        cardPanel.remove(cardLabel);
                        cardPanel.revalidate();
                        cardPanel.repaint();
                        turn = false; // После хода пользователя, устанавливаем, что ход окончен
                    }
                }
            });
            cardPanel.add(cardLabel);
            cardPanel.revalidate();
            cardPanel.repaint();
        } else {
            System.out.println("Изображение для карты не найдено: " + card);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CardGameClient::new);
    }
}