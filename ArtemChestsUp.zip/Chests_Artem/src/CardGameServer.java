import java.io.*;
import java.net.*;
import java.util.*;

public class CardGameServer {
    private static final int PORT = 12345;
    private static final int MAX_PLAYERS = 2;
    private static final List<ClientHandler> players = new ArrayList<>();
    private static final List<String> deck = new ArrayList<>();
    private static int currentPlayerIndex = 0;
    private static boolean gameStarted = false;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Сервер запущен на порту " + PORT);

            initializeDeck();

            while (players.size() < MAX_PLAYERS) {
                Socket socket = serverSocket.accept();
                ClientHandler player = new ClientHandler(socket, players.size());
                players.add(player);
                new Thread(player).start();
                System.out.println("Игрок " + players.size() + " подключился.");
            }

            if (players.size() == MAX_PLAYERS) {
                gameStarted = true;
                startGame();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void initializeDeck() {
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] values = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        for (String suit : suits) {
            for (String value : values) {
                deck.add(value + " of " + suit);
            }
        }
        Collections.shuffle(deck);
    }

    private static void startGame() {
        try {
            for (ClientHandler player : players) {
                for (int i = 0; i < 7; i++) {
                    player.sendCard(deck.remove(0));
                }
                player.sendMessage("Игра началась");
            }
            players.get(currentPlayerIndex).sendMessage("Ваш ход");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void checkForWin() {
        for (ClientHandler player : players) {
            if (player.getHandSize() == 0) {
                sendMessageToAll("Игрок " + (player.getPlayerIndex() + 1) + " победил!");
                endGame();
                break;
            }
        }
    }

    private static boolean checkHandPlayer(ClientHandler player, String card) {
            return player.getHand().stream().anyMatch(s -> s.contains(card));
    }

    private static void sendMessageToAll(String message) {
        for (ClientHandler player : players) {
            try {
                player.sendMessage(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void endGame() {
        for (ClientHandler player : players) {
            try {
                player.sendMessage("Игра окончена");
                player.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.exit(0);
    }

    private static class ClientHandler implements Runnable {
        private final Socket socket;
        private final int playerIndex;
        private final BufferedReader in;
        private final PrintWriter out;
        private final List<String> hand;

        public ClientHandler(Socket socket, int playerIndex) throws IOException {
            this.socket = socket;
            this.playerIndex = playerIndex;
            this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.out = new PrintWriter(socket.getOutputStream(), true);
            this.hand = new ArrayList<>();
        }

        @Override
        public void run() {
            try {
                while (true) {
                    String message = in.readLine();
                    if (message != null && message.startsWith("PLAY")) {
                        String[] parts = message.split(" ");
                        String card = parts[1] + " " + parts[2] + " " + parts[3];
                        if (hand.contains(card)) {
                            hand.remove(card);
                            System.out.println("Игрок " + (playerIndex + 1) + " игрок " + card);
                            sendMessageToAll("Игрок " + (playerIndex + 1) + " игрок " + card);
                            checkForWin();
                            if(!checkHandPlayer(players.get((currentPlayerIndex + 1) % MAX_PLAYERS), parts[1])){// || !checkHandPlayer(players.get((currentPlayerIndex + 1) % MAX_PLAYERS), parts[3])) {
                                currentPlayerIndex = (currentPlayerIndex + 1) % MAX_PLAYERS;
                            }
                            players.get(currentPlayerIndex).sendMessage("Ваш ход:");
                            players.get((currentPlayerIndex+1)%MAX_PLAYERS).sendMessage("Ход противника:");
                        } else {
                            sendMessage("Плохая карта. Рисуем карту из колоды.");
                            if (!deck.isEmpty()) {
                                sendCard(deck.remove(0));
                            } else {
                                sendMessage("Колода пуста.");
                            }
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        public void sendCard(String card) throws IOException {
            hand.add(card);
            out.println("CARD " + card);
        }

        public void sendMessage(String message) throws IOException {
            out.println(message);
        }

        public int getHandSize() {
            return hand.size();
        }

        public List<String> getHand() {
            return hand;
        }

        public int getPlayerIndex() {
            return playerIndex;
        }

        public void close() throws IOException {
            socket.close();
        }
    }
}
